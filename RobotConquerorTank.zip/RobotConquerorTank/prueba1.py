import Comandos as com

com.inicio()

com.derecha(4,200)




com.final()

com.cargar()




